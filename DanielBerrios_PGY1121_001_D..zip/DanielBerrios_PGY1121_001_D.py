import os
import numpy as np
import FuncionesCasaFeliz as fn
casa=np.empty([10,5], type(int))
piso=np.empty([10,5], type(int))
ruts=[]
fn.llenarMatriz(casa)
os.system("cls")
depa=0
op=0
while True:
    print("***Casa Feliz***")
    print("[1] Comprar departamento")
    print("[2] Mostrar departamento disponibles")
    print("[3] Ver listado de compradores")
    print("[4] Mostrar ganancias totales")
    print("[5] Salir")
    op=fn.valiaOp(op)
    if(op==1):
        dd=fn.validaPiso()
        td=fn.tipodepart()
        fn.mostrarDisponibles(piso)
        os.system("pause")
        
    if(op==2):
        print("Departamentos disponibles")
        fn.mostrarDisponibles(piso)
        os.system("pause")
    if(op==3):
        print("Listado de compradores")
        fn.Listado(ruts)
        os.system("pause")
    if op==4:
        print("Las ganacias totales")
       
    if(op==5):
        print("Muchas gracias Daniel Berrios Veas== Fecha: 11/07/2023")
        break