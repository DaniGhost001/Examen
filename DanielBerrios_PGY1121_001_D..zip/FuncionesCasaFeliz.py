import os
import numpy as np
def llenarMatriz(mat):
    p=1
    for i in range(10):
        for j in range(4):
            mat[i,j]=p
            p+=1
def valiaOp(op):
    while(True):
        try:
            op=int(input(" Elija opción: "))
            if(op>=1 and op<=5):
                break
            else:
                print("Debe ingresar opción entre 1 y 5")
        except ValueError:
            print("Debe ser un número entero")
    return op
def tipodepart():
    os.system("cls")
    tipo=0
    while(tipo<=0):
        try:
            print("1. Tipo A= $3.800") 
            print("2. Tipo B= $3.000") 
            print("3. Tipo C= $2.800") 
            print("4. Tipo D= $3.500") 
            print()
            tipo=int(input("Elija un tipo de departamento: "))
            if(tipo>=1 and tipo<=4):
                break
            else:
                print("Debe ingresar una opción válida")
        except ValueError:
            print("Ingrese un numero entero ")
    return tipo 

def mostrarDisponibles(de):
    os.system("cls")
    for i in range(10):
        print("\n")
        for j in range(4):
            if(j==1 or j==5):
                print("\t",de[i,j], end="")
            else:
                print("\t",de[i,j], end="")
    print("\n\n")

def validaPiso():
    piso=0
    while(True):
        try:
            piso=int(input(" Ingrese número de piso 1 al 10: "))
            if(piso>=1 and piso<=10):
                break
            else:
                print("Bebe ingresar un piso entre 1 y 10")
        except ValueError:
            print("Debe ser un número entero")
    return piso

def compraDepa(de,piso,tipo,depa,ruts):
    if(tipo==1):
        pago=3800
    if(tipo==2):
        pago=3000
    if(tipo==3):
        pago=2800
    if(tipo==4):
        pago=3500
    for i in range(10):
        for j in range(4):
            if(piso==de[i,j]):
                while(True):
                    while(True):
                        try:
                            rut=int(input("Rut debe tener 8 digitos minimo "))
                            if(rut<9999999):
                                print("ERROR, Debe tener 8 dígitos mínimo")
                            else:
                                break
                        except ValueError:
                            print("Debe ser número entero")
                    if(len(ruts)>0): 
                        sw=0
                        for y in range(len(ruts)):
                            if(rut==ruts[y]):
                                sw=1
                        if(sw==1):
                            print("El rut ya existe")
                        else:
                            ruts.append(rut)
                            break
                    else:
                        ruts.append(rut)
                        break
                depa[i,j]="X" 
                if(i>=0 and i<=2):
                    pago+=50000
                elif(i>=3 and i<=7):
                    pago+=20000
                elif(i>=11 and i<=12):
                    pago-=10000
                depa[i,j]=pago
def totalVenta(bus):
    suma=0
    casa=0
    for x in range(10):
        for i in range(4):
            if (casa[x,i]==0):
                if (i==1):
                    suma+=3800
                elif (i==2):
                    suma+=3000
                elif (i==3):
                    suma+=2800
                elif (i==4):
                    suma+=3500
    return suma
def ListadoCompr(r):
    r.sort()
    print("Listado de compradores")
    print("\t",r)